import { BelongsToManyGetAssociationsMixin } from 'sequelize';
import { CreationOptional } from 'sequelize';
import { default as default_2 } from 'node-cache';
import { EventEmitter } from 'events';
import { ForeignKey } from 'sequelize';
import { InferAttributes } from 'sequelize';
import { InferCreationAttributes } from 'sequelize';
import { Model } from 'sequelize';
import { ModelStatic } from 'sequelize';
import { NonAttribute } from 'sequelize';
import { QueryInterface } from 'sequelize';
import { Sequelize } from 'sequelize';
import { SyncOptions } from 'sequelize';

/**
 * Result from adding permissions to role
 */
export declare interface AddPermsToRoleResult {
    role: GuardRoleModel;
    permissions: GuardPermissionModel[];
}

/**
 * Bulk permission creation input
 */
export declare interface BulkPermissionInput {
    resource: string;
    actions: string | string[];
    name?: string;
}

/**
 * Options for creating permissions
 */
export declare interface CreatePermsOptions {
    name?: string;
    names?: string[];
    all?: boolean;
    json?: boolean;
}

/**
 * Options for creating roles
 */
export declare interface CreateRolesOptions {
    json?: boolean;
    all?: boolean;
}

/**
 * Rollback migrations - drop Guard tables
 * @param queryInterface
 * @param Sequelize
 * @param options
 */
declare function down(queryInterface: QueryInterface, _Sequelize: Sequelize, options?: GuardOptions): Promise<void>;

/**
 * Arguments for finding permissions
 */
export declare interface FindPermsArgs {
    name?: string;
    resource?: string;
    action?: string;
    search?: boolean;
}

/**
 * Arguments for finding roles
 */
export declare interface FindRolesArgs {
    name?: string;
    names?: string[];
    search?: boolean;
    withParent?: boolean;
}

/**
 * Extended NodeCache with Guard-specific methods
 */
declare class GuardCache extends default_2 {
    getRoles(): Record<number, GuardRoleModel>;
    getPerms(): Record<number, GuardPermissionModel>;
    setRoles(roles: Record<number, GuardRoleModel>): boolean;
    setPerms(perms: Record<number, GuardPermissionModel>): boolean;
    getRolesWithPerms(guard: SequelizeGuard): Promise<Record<number, GuardRoleModel>>;
}

/**
 * GuardControl - Fluent API for creating guard statements
 * @example
 * ```typescript
 * guard.init()
 *   .allow('admin')
 *   .to(['view', 'edit'])
 *   .on('blog')
 *   .commit();
 * ```
 */
declare class GuardControl {
    private guard;
    _roles: string;
    _actions: string[];
    _resources: string[];
    constructor(guard: SequelizeGuard);
    /**
     * Specify role to allow
     * @param roles - The name of role
     * @returns This GuardControl instance for chaining
     * @example
     * ```typescript
     * control.allow('admin')
     * ```
     */
    allow(roles: string): this;
    /**
     * Specify actions for current control
     * @param actions - The name(s) of actions
     * @returns This GuardControl instance for chaining
     * @example
     * ```typescript
     * control.to('view')
     * control.to(['view', 'edit'])
     * ```
     */
    to(actions: string | string[]): this;
    /**
     * Specify resources for current control
     * @param resources - The name(s) of resources
     * @returns This GuardControl instance for chaining
     * @example
     * ```typescript
     * control.on('blog')
     * control.on(['blog', 'post'])
     * ```
     */
    on(resources: string | string[]): this;
    /**
     * Commit current control - saves to database
     * @returns Promise resolved with role and assigned permissions
     * @example
     * ```typescript
     * await control.commit()
     * ```
     */
    commit(): Promise<AddPermsToRoleResult>;
}

/**
 * Event callback types
 */
export declare type GuardEventCallback<T> = (data: T) => void;

/**
 * Internal options with all defaults applied
 */
export declare interface GuardInternalOptions extends Required<GuardOptions> {
    tables: Required<NonNullable<GuardOptions['tables']>>;
}

/**
 * Collection of all Guard models
 */
declare interface GuardModels {
    GuardResource: GuardResourceModelStatic;
    GuardRole: GuardRoleModelStatic;
    GuardPermission: GuardPermissionModelStatic;
    RolePermission: GuardRolePermissionModelStatic;
    GuardUser: GuardUserModelStatic;
    RoleUser: GuardRoleUserModelStatic;
}

/**
 * Configuration options for SequelizeGuard
 */
export declare interface GuardOptions {
    /**
     * Table names configuration
     */
    tables?: {
        meta?: string;
        parents?: string;
        permissions?: string;
        resources?: string;
        roles?: string;
        users?: string;
    };
    /**
     * Prefix for guard tables in database
     * @default 'guard_'
     */
    prefix?: string;
    /**
     * Primary key for guard tables
     * @default 'id'
     */
    primaryKey?: string;
    /**
     * Add timestamps to tables
     * @default false
     */
    timestamps?: boolean;
    /**
     * Enable soft deletes of items
     * @default false
     */
    paranoid?: boolean;
    /**
     * Auto sync tables and initialize the cache; await guard.ready for completion.
     * Set false to defer database work to guard.sync(options) or use migrations.
     * @default true
     */
    sync?: boolean;
    /**
     * Debug mode, output logs
     * @default false
     */
    debug?: boolean;
    /**
     * Model used for User (pass model, not string name)
     * @default null
     */
    UserModel?: ModelStatic<GuardUserModel> | null;
    /**
     * Primary key used for User Model
     * @default 'id'
     */
    userPk?: string;
    /**
     * Roles or permissions can't be deleted while associated with other data
     * @default true
     */
    safeGuardDeletes?: boolean;
    /**
     * @deprecated Authorization and getUserRoles always read the database.
     * Retained for configuration compatibility; does not enable authorization caching.
     * @default true
     */
    userCache?: boolean;
    /**
     * TTL for entries manually stored in getUserCache() (in seconds).
     * Authorization does not read this cache.
     * @default 60
     */
    userCacheTtl?: number;
}

/**
 * GuardPermission Model - Represents permissions (e.g., view blog, edit post)
 */
declare interface GuardPermissionModel extends SequelizeModelClass<GuardPermissionModel> {
    id: CreationOptional<number>;
    name: string;
    description?: string;
    resource: string;
    action: string;
    allow: CreationOptional<number>;
    Roles?: NonAttribute<GuardRoleModel[]>;
}

declare type GuardPermissionModelStatic = ModelStatic<GuardPermissionModel>;

/**
 * GuardResource Model - Represents resources in the system (e.g., blog, post, image)
 */
declare interface GuardResourceModel extends SequelizeModelClass<GuardResourceModel> {
    id: CreationOptional<number>;
    name: string;
    description?: string;
}

declare type GuardResourceModelStatic = ModelStatic<GuardResourceModel>;

declare type GuardRoleData = {
    id: CreationOptional<number>;
    name: string;
    description?: string;
    parent_id?: ForeignKey<GuardRoleModel['id']>;
};

/**
 * GuardPermission Model - Represents permissions (e.g., view blog, edit post)
 */
declare interface GuardRoleModel extends SequelizeModelClass<GuardRoleModel>, GuardRoleData {
    Permissions?: NonAttribute<GuardPermissionModel[]>;
    Users?: NonAttribute<GuardUserModel[]>;
    ChildRoles?: NonAttribute<GuardRoleModel[]>;
    Parent?: NonAttribute<GuardRoleModel>;
    getPermissions?: BelongsToManyGetAssociationsMixin<GuardPermissionModel>;
    addPermissions?: (permissions: (GuardPermissionModel | number)[]) => Promise<void>;
    removePermissions?: (permissions: (GuardPermissionModel | number)[]) => Promise<void>;
    getRoles?: () => Promise<GuardRoleModel[]>;
    addRole?: (roleId: number) => Promise<void>;
    addRoles?: (roleIds: number[]) => Promise<void>;
    removeRoles?: (roles: GuardRoleModel[]) => Promise<void>;
}

declare type GuardRoleModelStatic = ModelStatic<GuardRoleModel>;

declare type GuardRolePermissionModelStatic = ModelStatic<RolePermissionModel>;

declare type GuardRoleUserModelStatic = ModelStatic<RoleUserModel>;

/**
 * User-specific cache for storing user roles
 */
declare class GuardUserCache extends default_2 {
    constructor(ttl?: number);
}

/**
 * GuardUser Model - Can be custom or default
 */
declare interface GuardUserModel extends SequelizeModelClass<GuardUserModel> {
    id: CreationOptional<number>;
    Roles?: NonAttribute<GuardRoleModel[]>;
    getRoles?: BelongsToManyGetAssociationsMixin<GuardRoleModel>;
    addRole?: (roleId: number) => Promise<void>;
    addRoles?: (roleIds: number[]) => Promise<void>;
    removeRoles?: (roles: GuardRoleModel[]) => Promise<void>;
    can?: (permission: string) => Promise<boolean>;
    cant?: (permission: string) => Promise<boolean>;
    isA?: (role: string) => Promise<boolean>;
    isAn?: (role: string) => Promise<boolean>;
    isAllOf?: (roles: string[]) => Promise<boolean>;
    isAnyOf?: (roles: string[]) => Promise<boolean>;
    /**
     * Assign single role to user
     * @param {{string}} role
     * @returns GuardUserModel
     */
    assignRole?: (role: string) => Promise<GuardUserModel>;
    /**
     * @deprecated Use `getRoles` association method instead
     */
    roles?: () => Promise<GuardRoleModel[]>;
    /**
     * Assign multiple roles to user
     * @param roles
     * @returns void
     */
    assignRoles?: (roles: string[]) => Promise<void>;
    /**
     * Remove assigned roles from user
     * @param roles
     * @returns void
     */
    rmAssignedRoles?: (roles: string[]) => Promise<void>;
}

declare type GuardUserModelStatic = ModelStatic<GuardUserModel>;

export declare const migration: {
    up: typeof up;
    down: typeof down;
};

/**
 * Internal permission data structure
 */
export declare interface PermissionData {
    name: string;
    resource: string;
    action: string;
}

declare type Prettify<T> = {
    [K in keyof T]: T[K];
} & {};

/**
 * Result from removing permissions from role
 */
export declare interface RemovePermsFromRoleResult {
    role: GuardRoleModel;
    permissions: GuardPermissionModel[];
    permsRemoved: GuardPermissionModel[];
}

/**
 * Result from role creation
 */
export declare type RoleCreationParam = string | RoleData;

/**
 * Result from role creation
 */
export declare interface RoleCreationResult {
    role: GuardRoleModel;
    created: boolean;
}

/**
 * Role data structure
 */
export declare interface RoleData {
    name: string;
    description?: string;
    parent_id?: number;
}

/**
 * RolePermission Junction Model
 */
declare interface RolePermissionModel extends SequelizeModelClass<RolePermissionModel> {
    id: CreationOptional<number>;
    role_id: ForeignKey<GuardRoleModel['id']>;
    permission_id: ForeignKey<GuardPermissionModel['id']>;
}

/**
 * RoleUser Junction Model
 */
declare interface RoleUserModel extends SequelizeModelClass<RoleUserModel> {
    id: CreationOptional<number>;
    role_id: ForeignKey<GuardRoleModel['id']>;
    user_id: ForeignKey<GuardUserModel['id']>;
}

/**
 * SequelizeGuard - Authorization library for Sequelize
 * @example
 * ```typescript
 * const sequelize = new Sequelize(...);
 * const guard = new SequelizeGuard(sequelize, options);
 *
 * // Assign roles
 * await user.assignRole('admin');
 *
 * // Create permissions
 * await guard.allow('admin', ['view', 'edit'], 'blog');
 *
 * // Check permissions
 * const canEdit = await user.can('edit blog');
 * ```
 */
declare class SequelizeGuard extends SequelizeGuardBase {
    /** Sequelize instance */
    readonly sequelize: SequelizeWithGuard;
    /* Excluded from this release type: _models */
    /**
     * Automatic startup completion, including model sync and cache initialization.
     * With sync: false, resolves without database work; await sync() separately
     * or prepare the tables with migrations before using the guard.
     * @example
     * ```typescript
     * const guard = new SequelizeGuard(sequelize, { sync: true });
     * await guard.ready;
     * // Now safe to use guard
     * ```
     */
    readonly ready: Promise<void>;
    private syncTask;
    /**
     * Creates a SequelizeGuard instance
     * @param sequelize - A Sequelize instance
     * @param options - Custom configuration options
     */
    constructor(sequelize: Sequelize, options?: GuardOptions);
    /**
     * Synchronize guard models, then reload their cached roles and permissions.
     * Calls are serialized, including automatic startup. Errors reject the caller.
     * Includes a supplied UserModel; unrelated Sequelize models are not synced.
     * schema must match every model's bound schema; per-call searchPath is rejected.
     * @param options - Sequelize sync options. force and alter may destroy data.
     * @returns This guard after synchronization and cache initialization complete.
     */
    sync(options?: SyncOptions): Promise<this>;
    /**
     * Get all Guard models
     * @example
     * ```typescript
     * const models = guard.models();
     * ```
     * @returns Array of models used in authorization
     */
    models(): GuardModels;
    /**
     * Migration utilities
     */
    static migration: {
        up: (queryInterface: QueryInterface, _Sequelize: Sequelize, options?: GuardOptions) => Promise<void>;
        down: (queryInterface: QueryInterface, _Sequelize: Sequelize, options?: GuardOptions) => Promise<void>;
    };
    init: () => GuardControl;
    allow: (role: string, actions: string | string[], resources: string | string[]) => Promise<AddPermsToRoleResult>;
    createPerms: (resources: string | string[], actions: string | string[], options?: CreatePermsOptions) => Promise<GuardPermissionModel[]>;
    createPermsBulk: (permissions: BulkPermissionInput[], options?: CreatePermsOptions) => Promise<GuardPermissionModel[]>;
    findPerms: (args?: FindPermsArgs) => Promise<GuardPermissionModel[]>;
    onPermsCreated: (cb: GuardEventCallback<GuardPermissionModel[]>) => UnsubscribeFn;
    onPermsAddedToRole: (cb: GuardEventCallback<GuardRoleModel>) => UnsubscribeFn;
    onPermsRemovedFromRole: (cb: GuardEventCallback<GuardRoleModel>) => UnsubscribeFn;
    _sanitizePermsInput: (resources: string | string[], actions: string | string[], options?: CreatePermsOptions) => PermissionData[];
    makeRole: (role: RoleCreationParam) => Promise<RoleCreationResult>;
    makeRoles: (roles: RoleCreationParam[], options?: CreateRolesOptions) => Promise<GuardRoleModel[]>;
    deleteRoles: (roles: string | RoleCreationParam[] | GuardRoleModel[]) => Promise<number>;
    allRoles: () => Promise<GuardRoleModel[]>;
    getRole: (role: string) => Promise<GuardRoleModel | null>;
    findRoles: (args?: FindRolesArgs) => Promise<GuardRoleModel[]>;
    addPermsToRole: (role: string | GuardRoleModel, actions: string | string[], resources: string | string[]) => Promise<AddPermsToRoleResult>;
    rmPermsFromRole: (role: string, actions: string | string[], resources: string | string[]) => Promise<RemovePermsFromRoleResult>;
    onRolesCreated: (cb: GuardEventCallback<GuardRoleModel[]>) => UnsubscribeFn;
    onRolesDeleted: (cb: GuardEventCallback<GuardRoleModel[]>) => UnsubscribeFn;
    makeUser: () => Promise<GuardUserModel>;
    assignRole: (user: GuardUserModel, role: string) => Promise<GuardUserModel>;
    assignRoles: (user: GuardUserModel, roles: string[]) => Promise<void>;
    rmAssignedRoles: (user: GuardUserModel, roles: string[]) => Promise<void>;
    getUserRoles: (user: GuardUserModel) => Promise<GuardRoleData[]>;
    userCan: (user: GuardUserModel, permission: string) => Promise<boolean>;
    userCant: (user: GuardUserModel, permission: string) => Promise<boolean>;
    resolvePermission: (givenPermissions: {
        action: string;
        resource: string;
    }[], wantedPermission: string) => boolean;
    userHasRoles: (user: GuardUserModel, roles: string[]) => Promise<boolean>;
    userHasAllRoles: (user: GuardUserModel, roles: string[]) => Promise<boolean>;
    userIsA: (user: GuardUserModel, role: string) => Promise<boolean>;
    resetCache: () => GuardCache;
    getCache: () => Promise<GuardCache>;
    resetUserCache: () => GuardUserCache;
    getUserCache: () => GuardUserCache;
}
export { SequelizeGuard }
export default SequelizeGuard;

declare abstract class SequelizeGuardBase {
    /** Guard configuration options */
    readonly options: GuardInternalOptions;
    /* Excluded from this release type: _ee */
    /* Excluded from this release type: _cache */
    /* Excluded from this release type: _cacheReady */
    /* Excluded from this release type: _userCache */
    constructor(options?: GuardOptions);
    /* Excluded from this release type: on */
    /* Excluded from this release type: once */
    /* Excluded from this release type: emit */
}

declare type SequelizeModelClass<ModelType extends Model = Model> = Model<InferAttributes<ModelType>, InferCreationAttributes<ModelType>>;

declare type SequelizeWithGuard<S extends Sequelize = Sequelize, O extends GuardOptions = GuardOptions> = S & {
    guard: SequelizeGuard;
    models: Prettify<S['models'] & {
        GuardModels: GuardModels;
    } & (O extends {
        UserModel: infer U;
    } ? {
        User: U;
    } : {
        User: GuardModels['GuardUser'];
    })>;
};

export declare type UnsubscribeFn = () => void;

/**
 * Run migrations to create Guard tables
 * @param queryInterface
 * @param Sequelize
 * @param options
 */
declare function up(queryInterface: QueryInterface, _Sequelize: Sequelize, options?: GuardOptions): Promise<void>;

export { }
